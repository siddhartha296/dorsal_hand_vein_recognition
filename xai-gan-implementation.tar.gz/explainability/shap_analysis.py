"""
SHAP (SHapley Additive exPlanations) Analysis
For global feature importance in vein authentication
"""
import torch
import numpy as np
import shap
import matplotlib.pyplot as plt
from tqdm import tqdm


class VeinSHAPAnalyzer:
    """
    SHAP analyzer for dorsal hand vein authentication
    Provides global and local explanations of model decisions
    """
    def __init__(self, model, background_data, device='cuda'):
        """
        Args:
            model: Trained authentication model
            background_data: Background dataset for SHAP (typically subset of training data)
            device: Device to run computations
        """
        self.model = model
        self.device = device
        self.model.to(device)
        self.model.eval()
        
        # Prepare background data
        if isinstance(background_data, torch.utils.data.DataLoader):
            self.background = self._extract_background(background_data)
        else:
            self.background = background_data.to(device)
    
    def _extract_background(self, dataloader, max_samples=100):
        """Extract background samples from dataloader"""
        background_samples = []
        
        for images, _ in dataloader:
            background_samples.append(images)
            if len(background_samples) * images.size(0) >= max_samples:
                break
        
        background = torch.cat(background_samples, dim=0)[:max_samples]
        return background.to(self.device)
    
    def create_explainer(self, method='gradient'):
        """
        Create SHAP explainer
        
        Args:
            method: 'gradient', 'deep', or 'kernel'
        """
        if method == 'gradient':
            self.explainer = shap.GradientExplainer(
                self.model,
                self.background
            )
        elif method == 'deep':
            self.explainer = shap.DeepExplainer(
                self.model,
                self.background
            )
        elif method == 'kernel':
            # Wrapper for model prediction
            def model_predict(x):
                x_tensor = torch.FloatTensor(x).to(self.device)
                with torch.no_grad():
                    output = self.model(x_tensor)
                return output.cpu().numpy()
            
            self.explainer = shap.KernelExplainer(
                model_predict,
                self.background.cpu().numpy()
            )
        else:
            raise ValueError(f"Unknown method: {method}")
        
        return self.explainer
    
    def explain_instance(self, input_image, target_class=None):
        """
        Generate SHAP values for a single instance
        
        Args:
            input_image: Input tensor (1, C, H, W) or (C, H, W)
            target_class: Target class (if None, use predicted)
            
        Returns:
            shap_values: SHAP values for the instance
            prediction: Model prediction
        """
        if input_image.dim() == 3:
            input_image = input_image.unsqueeze(0)
        
        input_image = input_image.to(self.device)
        
        # Get prediction
        with torch.no_grad():
            output = self.model(input_image)
            pred_class = output.argmax(dim=1).item()
        
        if target_class is None:
            target_class = pred_class
        
        # Compute SHAP values
        shap_values = self.explainer.shap_values(input_image)
        
        # If multi-class, select target class
        if isinstance(shap_values, list):
            shap_values = shap_values[target_class]
        
        return shap_values, pred_class
    
    def batch_explain(self, dataloader, num_samples=100):
        """
        Generate SHAP values for multiple samples
        
        Args:
            dataloader: DataLoader with samples
            num_samples: Number of samples to explain
            
        Returns:
            all_shap_values: List of SHAP values
            all_predictions: List of predictions
            all_labels: List of true labels
        """
        all_shap_values = []
        all_predictions = []
        all_labels = []
        
        total_processed = 0
        
        for images, labels in tqdm(dataloader, desc="Computing SHAP"):
            if total_processed >= num_samples:
                break
            
            images = images.to(self.device)
            
            # Get SHAP values for batch
            shap_values = self.explainer.shap_values(images)
            
            # Get predictions
            with torch.no_grad():
                outputs = self.model(images)
                predictions = outputs.argmax(dim=1)
            
            # Store results
            if isinstance(shap_values, list):
                # Multi-class: store SHAP values for predicted class
                for i, pred in enumerate(predictions):
                    all_shap_values.append(shap_values[pred.item()][i])
            else:
                all_shap_values.extend(shap_values)
            
            all_predictions.extend(predictions.cpu().numpy())
            all_labels.extend(labels.numpy())
            
            total_processed += len(images)
        
        return all_shap_values, all_predictions, all_labels
    
    def global_importance_analysis(self, shap_values):
        """
        Analyze global feature importance
        
        Args:
            shap_values: List or array of SHAP values
            
        Returns:
            importance_map: Spatial importance map
            statistics: Dictionary with importance statistics
        """
        # Convert to numpy array if needed
        if isinstance(shap_values, list):
            shap_values = np.array(shap_values)
        
        # Compute mean absolute SHAP values
        mean_abs_shap = np.abs(shap_values).mean(axis=0)
        
        # Spatial importance map (average across channels if needed)
        if mean_abs_shap.ndim == 3:  # (C, H, W)
            importance_map = mean_abs_shap.mean(axis=0)
        else:  # (H, W)
            importance_map = mean_abs_shap
        
        # Compute statistics
        statistics = {
            'mean_importance': importance_map.mean(),
            'std_importance': importance_map.std(),
            'max_importance': importance_map.max(),
            'min_importance': importance_map.min(),
            'top_10_percent_threshold': np.percentile(importance_map, 90),
            'top_5_percent_threshold': np.percentile(importance_map, 95)
        }
        
        return importance_map, statistics
    
    def visualize_shap_instance(self, input_image, shap_values, save_path=None):
        """
        Visualize SHAP values for a single instance
        
        Args:
            input_image: Original input image
            shap_values: SHAP values for the instance
            save_path: Path to save visualization
        """
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        # Original image
        if isinstance(input_image, torch.Tensor):
            img = input_image.cpu().numpy()
        else:
            img = input_image
        
        if img.ndim == 4:
            img = img[0, 0]  # (1, C, H, W) -> (H, W)
        elif img.ndim == 3:
            img = img[0]  # (C, H, W) -> (H, W)
        
        axes[0].imshow(img, cmap='gray')
        axes[0].set_title('Original Image')
        axes[0].axis('off')
        
        # SHAP heatmap
        shap_map = np.abs(shap_values)
        if shap_map.ndim == 3:
            shap_map = shap_map.mean(axis=0)
        
        im = axes[1].imshow(shap_map, cmap='hot')
        axes[1].set_title('SHAP Importance')
        axes[1].axis('off')
        plt.colorbar(im, ax=axes[1])
        
        # Overlay
        overlay = img.copy()
        overlay = (overlay - overlay.min()) / (overlay.max() - overlay.min() + 1e-8)
        
        shap_normalized = (shap_map - shap_map.min()) / (shap_map.max() - shap_map.min() + 1e-8)
        overlay = 0.7 * overlay + 0.3 * shap_normalized
        
        axes[2].imshow(overlay, cmap='gray')
        axes[2].set_title('SHAP Overlay')
        axes[2].axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def visualize_global_importance(self, importance_map, save_path=None):
        """
        Visualize global feature importance
        
        Args:
            importance_map: Spatial importance map
            save_path: Path to save visualization
        """
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Heatmap
        im1 = axes[0].imshow(importance_map, cmap='hot')
        axes[0].set_title('Global Feature Importance')
        axes[0].axis('off')
        plt.colorbar(im1, ax=axes[0])
        
        # Histogram
        axes[1].hist(importance_map.flatten(), bins=50, alpha=0.7, color='blue')
        axes[1].set_xlabel('SHAP Importance Value')
        axes[1].set_ylabel('Frequency')
        axes[1].set_title('Distribution of Importance Values')
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def analyze_vein_regions(self, importance_map, num_regions=5):
        """
        Identify most important vein regions
        
        Args:
            importance_map: Spatial importance map
            num_regions: Number of top regions to identify
            
        Returns:
            regions: List of important regions with coordinates
        """
        # Find top importance regions
        threshold = np.percentile(importance_map, 95)
        important_mask = importance_map > threshold
        
        # Label connected components
        from scipy import ndimage
        labeled, num_features = ndimage.label(important_mask)
        
        regions = []
        for i in range(1, min(num_features + 1, num_regions + 1)):
            region_mask = labeled == i
            region_coords = np.argwhere(region_mask)
            
            if len(region_coords) > 0:
                center = region_coords.mean(axis=0)
                importance = importance_map[region_mask].mean()
                size = len(region_coords)
                
                regions.append({
                    'id': i,
                    'center': center,
                    'importance': importance,
                    'size': size,
                    'coords': region_coords
                })
        
        # Sort by importance
        regions.sort(key=lambda x: x['importance'], reverse=True)
        
        return regions


def test_shap_analyzer():
    """Test SHAP analyzer"""
    from models.classifier import VeinAuthenticationClassifier
    
    # Create dummy model and data
    model = VeinAuthenticationClassifier(num_classes=10)
    background = torch.randn(20, 1, 224, 224)
    
    # Create analyzer
    analyzer = VeinSHAPAnalyzer(model, background, device='cpu')
    analyzer.create_explainer(method='gradient')
    
    # Test single instance
    test_image = torch.randn(1, 1, 224, 224)
    shap_values, pred = analyzer.explain_instance(test_image)
    
    print(f"SHAP values shape: {shap_values.shape}")
    print(f"Predicted class: {pred}")
    print(f"SHAP value range: [{shap_values.min():.4f}, {shap_values.max():.4f}]")
    
    # Test global analysis
    importance_map, stats = analyzer.global_importance_analysis([shap_values])
    print(f"\nImportance map shape: {importance_map.shape}")
    print(f"Mean importance: {stats['mean_importance']:.4f}")
    
    return analyzer


if __name__ == "__main__":
    test_shap_analyzer()
