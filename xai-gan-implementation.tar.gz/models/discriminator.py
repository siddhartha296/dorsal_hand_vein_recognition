"""
Discriminator Network for Dorsal Hand Vein Authentication
Using Wasserstein GAN with Gradient Penalty (WGAN-GP)
"""
import torch
import torch.nn as nn


class SpectralNorm(nn.Module):
    """Spectral Normalization wrapper"""
    def __init__(self, module, name='weight', power_iterations=1):
        super(SpectralNorm, self).__init__()
        self.module = module
        self.name = name
        self.power_iterations = power_iterations
        if not self._made_params():
            self._make_params()

    def _made_params(self):
        try:
            u = getattr(self.module, self.name + "_u")
            v = getattr(self.module, self.name + "_v")
            w = getattr(self.module, self.name + "_bar")
            return True
        except AttributeError:
            return False

    def _make_params(self):
        w = getattr(self.module, self.name)
        height = w.data.shape[0]
        width = w.view(height, -1).data.shape[1]

        u = nn.Parameter(w.data.new(height).normal_(0, 1), requires_grad=False)
        v = nn.Parameter(w.data.new(width).normal_(0, 1), requires_grad=False)
        u.data = self._l2normalize(u.data)
        v.data = self._l2normalize(v.data)
        w_bar = nn.Parameter(w.data)

        del self.module._parameters[self.name]
        self.module.register_parameter(self.name + "_u", u)
        self.module.register_parameter(self.name + "_v", v)
        self.module.register_parameter(self.name + "_bar", w_bar)

    def _l2normalize(self, v, eps=1e-12):
        return v / (v.norm() + eps)

    def forward(self, *args):
        self._update_u_v()
        return self.module.forward(*args)

    def _update_u_v(self):
        u = getattr(self.module, self.name + "_u")
        v = getattr(self.module, self.name + "_v")
        w = getattr(self.module, self.name + "_bar")

        height = w.data.shape[0]
        for _ in range(self.power_iterations):
            v.data = self._l2normalize(torch.mv(torch.t(w.view(height, -1).data), u.data))
            u.data = self._l2normalize(torch.mv(w.view(height, -1).data, v.data))

        sigma = u.dot(w.view(height, -1).mv(v))
        setattr(self.module, self.name, w / sigma.expand_as(w))


class MinibatchDiscrimination(nn.Module):
    """Minibatch discrimination to prevent mode collapse"""
    def __init__(self, in_features, out_features, kernel_dims, mean=False):
        super(MinibatchDiscrimination, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.kernel_dims = kernel_dims
        self.mean = mean
        self.T = nn.Parameter(torch.Tensor(in_features, out_features, kernel_dims))
        nn.init.normal_(self.T, 0, 1)

    def forward(self, x):
        # x: batch_size x in_features
        matrices = x.mm(self.T.view(self.in_features, -1))
        matrices = matrices.view(-1, self.out_features, self.kernel_dims)

        M = matrices.unsqueeze(0)  # 1 x batch_size x out_features x kernel_dims
        M_T = M.permute(1, 0, 2, 3)  # batch_size x 1 x out_features x kernel_dims
        norm = torch.abs(M - M_T).sum(3)  # batch_size x batch_size x out_features
        expnorm = torch.exp(-norm)
        o_b = (expnorm.sum(0) - 1)   # batch_size x out_features

        if self.mean:
            o_b /= x.size(0) - 1

        x = torch.cat([x, o_b], 1)
        return x


class Discriminator(nn.Module):
    """
    Discriminator Network with Spectral Normalization
    
    Architecture:
    - Input: Vein image (1 x 224 x 224)
    - Output: Wasserstein distance estimate (real vs fake)
    - Features: Spectral normalization, minibatch discrimination
    """
    def __init__(self, img_channels=1, features=64):
        super(Discriminator, self).__init__()
        
        # Convolutional feature extraction
        self.conv_blocks = nn.Sequential(
            # Input: 1 x 224 x 224
            nn.Conv2d(img_channels, features, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 64 x 112 x 112
            nn.Conv2d(features, features * 2, 4, 2, 1),
            nn.BatchNorm2d(features * 2),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 128 x 56 x 56
            nn.Conv2d(features * 2, features * 4, 4, 2, 1),
            nn.BatchNorm2d(features * 4),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 256 x 28 x 28
            nn.Conv2d(features * 4, features * 8, 4, 2, 1),
            nn.BatchNorm2d(features * 8),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 512 x 14 x 14
            nn.Conv2d(features * 8, features * 16, 4, 2, 1),
            nn.BatchNorm2d(features * 16),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 1024 x 7 x 7
            nn.Conv2d(features * 16, features * 16, 4, 2, 1),
            nn.BatchNorm2d(features * 16),
            nn.LeakyReLU(0.2, inplace=True),
        )
        
        # Calculate flattened size
        self.flat_features = features * 16 * 3 * 3
        
        # Minibatch discrimination
        self.minibatch_disc = MinibatchDiscrimination(
            self.flat_features, 50, 5
        )
        
        # Final classification
        self.fc = nn.Sequential(
            nn.Linear(self.flat_features + 50, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 1)
        )
        
    def forward(self, img):
        # Extract features
        features = self.conv_blocks(img)
        features = features.view(features.size(0), -1)
        
        # Apply minibatch discrimination
        features = self.minibatch_disc(features)
        
        # Final output (Wasserstein distance)
        validity = self.fc(features)
        
        return validity


class PatchDiscriminator(nn.Module):
    """
    PatchGAN Discriminator for local texture discrimination
    Outputs a matrix of predictions rather than single value
    """
    def __init__(self, img_channels=1, features=64):
        super(PatchDiscriminator, self).__init__()
        
        self.model = nn.Sequential(
            # Input: 1 x 224 x 224
            nn.Conv2d(img_channels, features, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 64 x 112 x 112
            nn.Conv2d(features, features * 2, 4, 2, 1),
            nn.BatchNorm2d(features * 2),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 128 x 56 x 56
            nn.Conv2d(features * 2, features * 4, 4, 2, 1),
            nn.BatchNorm2d(features * 4),
            nn.LeakyReLU(0.2, inplace=True),
            
            # 256 x 28 x 28
            nn.Conv2d(features * 4, features * 8, 4, 1, 1),
            nn.BatchNorm2d(features * 8),
            nn.LeakyReLU(0.2, inplace=True),
            
            # Output patch predictions
            nn.Conv2d(features * 8, 1, 4, 1, 1),
        )
        
    def forward(self, img):
        return self.model(img)


def gradient_penalty(discriminator, real_samples, fake_samples, device):
    """
    Compute gradient penalty for WGAN-GP
    """
    batch_size = real_samples.size(0)
    
    # Random weight for interpolation
    alpha = torch.rand(batch_size, 1, 1, 1).to(device)
    
    # Interpolated samples
    interpolates = (alpha * real_samples + (1 - alpha) * fake_samples).requires_grad_(True)
    
    # Discriminator output for interpolated samples
    d_interpolates = discriminator(interpolates)
    
    # Compute gradients
    fake = torch.ones(d_interpolates.size()).to(device)
    gradients = torch.autograd.grad(
        outputs=d_interpolates,
        inputs=interpolates,
        grad_outputs=fake,
        create_graph=True,
        retain_graph=True,
        only_inputs=True,
    )[0]
    
    # Calculate gradient penalty
    gradients = gradients.view(batch_size, -1)
    gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
    
    return gradient_penalty


def test_discriminator():
    """Test the discriminator architecture"""
    batch_size = 4
    img_channels = 1
    
    disc = Discriminator(img_channels=img_channels)
    x = torch.randn(batch_size, img_channels, 224, 224)
    
    output = disc(x)
    print(f"Discriminator Output Shape: {output.shape}")
    print(f"Expected: ({batch_size}, 1)")
    print(f"Total Parameters: {sum(p.numel() for p in disc.parameters()):,}")
    
    # Test PatchDiscriminator
    patch_disc = PatchDiscriminator(img_channels=img_channels)
    patch_output = patch_disc(x)
    print(f"\nPatchDiscriminator Output Shape: {patch_output.shape}")
    
    return disc, patch_disc


if __name__ == "__main__":
    test_discriminator()
