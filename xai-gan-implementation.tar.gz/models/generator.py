"""
Generator Network with Self-Attention for Dorsal Hand Vein Synthesis
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class SelfAttention(nn.Module):
    """Self-Attention module for generator"""
    def __init__(self, in_channels):
        super(SelfAttention, self).__init__()
        self.in_channels = in_channels
        
        # Query, Key, Value projections
        self.query = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        
        # Learnable scaling parameter
        self.gamma = nn.Parameter(torch.zeros(1))
        
    def forward(self, x):
        batch_size, C, H, W = x.size()
        
        # Project to query, key, value
        query = self.query(x).view(batch_size, -1, H * W)  # B x C' x (H*W)
        key = self.key(x).view(batch_size, -1, H * W)      # B x C' x (H*W)
        value = self.value(x).view(batch_size, -1, H * W)  # B x C x (H*W)
        
        # Attention scores
        attention = torch.bmm(query.permute(0, 2, 1), key)  # B x (H*W) x (H*W)
        attention = F.softmax(attention, dim=-1)
        
        # Apply attention to values
        out = torch.bmm(value, attention.permute(0, 2, 1))
        out = out.view(batch_size, C, H, W)
        
        # Residual connection with learnable weight
        out = self.gamma * out + x
        
        return out


class ResidualBlock(nn.Module):
    """Residual block for generator"""
    def __init__(self, channels):
        super(ResidualBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(channels)
        )
        
    def forward(self, x):
        return x + self.block(x)


class Generator(nn.Module):
    """
    Generator with Attention Mechanism for Vein Pattern Synthesis
    
    Architecture:
    - Input: Latent vector (z) of dimension latent_dim
    - Output: Synthetic vein image (1 x H x W)
    - Features: Self-attention at multiple scales, residual connections
    """
    def __init__(self, latent_dim=100, img_channels=1, features=64):
        super(Generator, self).__init__()
        self.latent_dim = latent_dim
        self.init_size = 7  # Initial spatial size (7x7)
        
        # Project latent vector to initial feature map
        self.fc = nn.Sequential(
            nn.Linear(latent_dim, features * 8 * self.init_size * self.init_size),
            nn.BatchNorm1d(features * 8 * self.init_size * self.init_size),
            nn.ReLU(inplace=True)
        )
        
        # Upsampling layers with attention
        self.conv_blocks = nn.ModuleList([
            # 7x7 -> 14x14
            nn.Sequential(
                nn.ConvTranspose2d(features * 8, features * 4, 4, 2, 1),
                nn.BatchNorm2d(features * 4),
                nn.ReLU(inplace=True),
            ),
            # 14x14 -> 28x28
            nn.Sequential(
                nn.ConvTranspose2d(features * 4, features * 2, 4, 2, 1),
                nn.BatchNorm2d(features * 2),
                nn.ReLU(inplace=True),
            ),
            # 28x28 -> 56x56
            nn.Sequential(
                nn.ConvTranspose2d(features * 2, features, 4, 2, 1),
                nn.BatchNorm2d(features),
                nn.ReLU(inplace=True),
            ),
            # 56x56 -> 112x112
            nn.Sequential(
                nn.ConvTranspose2d(features, features // 2, 4, 2, 1),
                nn.BatchNorm2d(features // 2),
                nn.ReLU(inplace=True),
            ),
            # 112x112 -> 224x224
            nn.Sequential(
                nn.ConvTranspose2d(features // 2, features // 4, 4, 2, 1),
                nn.BatchNorm2d(features // 4),
                nn.ReLU(inplace=True),
            ),
        ])
        
        # Self-attention at 28x28 and 56x56 resolutions
        self.attention1 = SelfAttention(features * 2)  # After 28x28
        self.attention2 = SelfAttention(features)       # After 56x56
        
        # Residual blocks for vein detail refinement
        self.residual_blocks = nn.Sequential(
            ResidualBlock(features // 4),
            ResidualBlock(features // 4),
            ResidualBlock(features // 4)
        )
        
        # Final output layer
        self.output = nn.Sequential(
            nn.Conv2d(features // 4, img_channels, 3, padding=1),
            nn.Tanh()  # Output in range [-1, 1]
        )
        
    def forward(self, z):
        # Project and reshape
        x = self.fc(z)
        x = x.view(x.size(0), -1, self.init_size, self.init_size)
        
        # Upsampling with attention
        x = self.conv_blocks[0](x)  # 14x14
        x = self.conv_blocks[1](x)  # 28x28
        x = self.attention1(x)       # Apply attention
        
        x = self.conv_blocks[2](x)  # 56x56
        x = self.attention2(x)       # Apply attention
        
        x = self.conv_blocks[3](x)  # 112x112
        x = self.conv_blocks[4](x)  # 224x224
        
        # Refine with residual blocks
        x = self.residual_blocks(x)
        
        # Generate final image
        x = self.output(x)
        
        return x


def test_generator():
    """Test the generator architecture"""
    latent_dim = 100
    batch_size = 4
    
    gen = Generator(latent_dim=latent_dim)
    z = torch.randn(batch_size, latent_dim)
    
    output = gen(z)
    print(f"Generator Output Shape: {output.shape}")
    print(f"Expected: ({batch_size}, 1, 224, 224)")
    print(f"Total Parameters: {sum(p.numel() for p in gen.parameters()):,}")
    
    return gen


if __name__ == "__main__":
    test_generator()
