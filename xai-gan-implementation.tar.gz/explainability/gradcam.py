"""
Grad-CAM (Gradient-weighted Class Activation Mapping) Implementation
For visualizing which vein patterns contribute to authentication decisions
"""
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import matplotlib.pyplot as plt
from matplotlib import cm


class GradCAM:
    """
    Grad-CAM implementation for CNN visualization
    
    Reference:
    Selvaraju et al. "Grad-CAM: Visual Explanations from Deep Networks 
    via Gradient-based Localization" (ICCV 2017)
    """
    def __init__(self, model, target_layer):
        """
        Args:
            model: The classification model
            target_layer: Layer to extract activations from (e.g., 'layer4')
        """
        self.model = model
        self.target_layer = target_layer
        self.gradients = None
        self.activations = None
        
        # Register hooks
        self._register_hooks()
        
    def _register_hooks(self):
        """Register forward and backward hooks"""
        def forward_hook(module, input, output):
            self.activations = output.detach()
            
        def backward_hook(module, grad_input, grad_output):
            self.gradients = grad_output[0].detach()
        
        # Get target layer
        target_module = dict(self.model.named_modules())[self.target_layer]
        
        # Register hooks
        target_module.register_forward_hook(forward_hook)
        target_module.register_full_backward_hook(backward_hook)
        
    def generate_cam(self, input_image, target_class=None):
        """
        Generate Grad-CAM heatmap
        
        Args:
            input_image: Input tensor (1, C, H, W)
            target_class: Target class index (if None, uses predicted class)
            
        Returns:
            cam: Grad-CAM heatmap (H, W)
            prediction: Model prediction
        """
        # Forward pass
        self.model.eval()
        output = self.model(input_image)
        
        if target_class is None:
            target_class = output.argmax(dim=1).item()
        
        # Zero gradients
        self.model.zero_grad()
        
        # Backward pass for target class
        class_loss = output[0, target_class]
        class_loss.backward()
        
        # Get gradients and activations
        gradients = self.gradients[0]  # (C, H, W)
        activations = self.activations[0]  # (C, H, W)
        
        # Global average pooling of gradients
        weights = gradients.mean(dim=(1, 2), keepdim=True)  # (C, 1, 1)
        
        # Weighted combination of activation maps
        cam = (weights * activations).sum(dim=0)  # (H, W)
        
        # ReLU to keep only positive influences
        cam = F.relu(cam)
        
        # Normalize
        cam = cam - cam.min()
        cam = cam / (cam.max() + 1e-8)
        
        return cam.cpu().numpy(), output, target_class
    
    def visualize(self, input_image, cam, original_image=None, save_path=None):
        """
        Visualize Grad-CAM overlay on original image
        
        Args:
            input_image: Preprocessed input tensor
            cam: Grad-CAM heatmap
            original_image: Original image (for overlay)
            save_path: Path to save visualization
        """
        # Resize CAM to input image size
        cam_resized = cv2.resize(cam, (224, 224))
        
        # Convert to heatmap
        heatmap = cm.jet(cam_resized)[:, :, :3]  # RGB
        
        # Prepare original image
        if original_image is None:
            original_image = input_image[0, 0].cpu().numpy()
        
        # Normalize original image to [0, 1]
        img_normalized = (original_image - original_image.min()) / \
                        (original_image.max() - original_image.min() + 1e-8)
        
        # Convert grayscale to RGB
        img_rgb = np.stack([img_normalized] * 3, axis=-1)
        
        # Overlay heatmap
        overlay = 0.5 * img_rgb + 0.5 * heatmap
        overlay = np.clip(overlay, 0, 1)
        
        # Create visualization
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        axes[0].imshow(img_normalized, cmap='gray')
        axes[0].set_title('Original Image')
        axes[0].axis('off')
        
        axes[1].imshow(cam_resized, cmap='jet')
        axes[1].set_title('Grad-CAM Heatmap')
        axes[1].axis('off')
        
        axes[2].imshow(overlay)
        axes[2].set_title('Grad-CAM Overlay')
        axes[2].axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig


class GuidedBackprop:
    """
    Guided Backpropagation for fine-grained visualization
    Shows which pixels are most important
    """
    def __init__(self, model):
        self.model = model
        self.gradients = None
        self._register_hooks()
        
    def _register_hooks(self):
        """Modify ReLU backward pass"""
        def relu_backward_hook(module, grad_input, grad_output):
            # Only keep positive gradients (guided backprop)
            return (F.relu(grad_input[0]),)
        
        # Register for all ReLU layers
        for module in self.model.modules():
            if isinstance(module, torch.nn.ReLU):
                module.register_full_backward_hook(relu_backward_hook)
    
    def generate_gradients(self, input_image, target_class=None):
        """
        Generate guided backpropagation gradients
        
        Args:
            input_image: Input tensor (1, C, H, W)
            target_class: Target class index
            
        Returns:
            gradients: Gradient map
        """
        input_image.requires_grad_()
        
        # Forward pass
        self.model.eval()
        output = self.model(input_image)
        
        if target_class is None:
            target_class = output.argmax(dim=1).item()
        
        # Backward pass
        self.model.zero_grad()
        class_loss = output[0, target_class]
        class_loss.backward()
        
        # Get gradients
        gradients = input_image.grad[0].cpu().numpy()
        
        return gradients, target_class


class GradCAMPlusPlus(GradCAM):
    """
    Grad-CAM++ - Improved version with better localization
    
    Reference:
    Chattopadhyay et al. "Grad-CAM++: Improved Visual Explanations for 
    Deep Convolutional Networks" (WACV 2018)
    """
    def generate_cam(self, input_image, target_class=None):
        """Generate Grad-CAM++ heatmap"""
        # Forward pass
        self.model.eval()
        output = self.model(input_image)
        
        if target_class is None:
            target_class = output.argmax(dim=1).item()
        
        # Backward pass
        self.model.zero_grad()
        class_loss = output[0, target_class]
        class_loss.backward(retain_graph=True)
        
        # Get gradients and activations
        gradients = self.gradients[0]  # (C, H, W)
        activations = self.activations[0]  # (C, H, W)
        
        # Compute alpha weights (Grad-CAM++ improvement)
        numerator = gradients.pow(2)
        denominator = 2 * gradients.pow(2) + \
                     (activations * gradients.pow(3)).sum(dim=(1, 2), keepdim=True)
        
        alpha = numerator / (denominator + 1e-8)
        
        # ReLU and weighted combination
        weights = (alpha * F.relu(gradients)).sum(dim=(1, 2), keepdim=True)
        
        # Generate CAM
        cam = (weights * activations).sum(dim=0)
        cam = F.relu(cam)
        
        # Normalize
        cam = cam - cam.min()
        cam = cam / (cam.max() + 1e-8)
        
        return cam.cpu().numpy(), output, target_class


def analyze_vein_patterns(model, dataloader, target_layer='layer4', num_samples=10):
    """
    Analyze which vein patterns are most discriminative
    
    Args:
        model: Trained classification model
        dataloader: DataLoader with vein images
        target_layer: Layer for Grad-CAM
        num_samples: Number of samples to analyze
        
    Returns:
        analysis_results: Dictionary with pattern statistics
    """
    gradcam = GradCAM(model, target_layer)
    
    all_cams = []
    all_predictions = []
    all_labels = []
    
    for i, (images, labels) in enumerate(dataloader):
        if i >= num_samples:
            break
            
        images = images.to(next(model.parameters()).device)
        
        for img, label in zip(images, labels):
            cam, output, pred = gradcam.generate_cam(img.unsqueeze(0))
            
            all_cams.append(cam)
            all_predictions.append(pred)
            all_labels.append(label.item())
    
    # Compute statistics
    avg_cam = np.mean(all_cams, axis=0)
    std_cam = np.std(all_cams, axis=0)
    
    # Find most important regions
    top_10_percent_threshold = np.percentile(avg_cam, 90)
    important_regions = avg_cam > top_10_percent_threshold
    
    results = {
        'average_cam': avg_cam,
        'std_cam': std_cam,
        'important_regions': important_regions,
        'accuracy': np.mean([p == l for p, l in zip(all_predictions, all_labels)]),
        'num_samples': len(all_cams)
    }
    
    return results


def test_gradcam():
    """Test Grad-CAM implementation"""
    from models.classifier import VeinAuthenticationClassifier
    
    # Create dummy model
    model = VeinAuthenticationClassifier(num_classes=10)
    model.eval()
    
    # Create dummy input
    input_image = torch.randn(1, 1, 224, 224)
    
    # Test Grad-CAM
    gradcam = GradCAM(model, target_layer='layer4')
    cam, output, pred_class = gradcam.generate_cam(input_image)
    
    print(f"CAM shape: {cam.shape}")
    print(f"Predicted class: {pred_class}")
    print(f"CAM min: {cam.min():.4f}, max: {cam.max():.4f}")
    
    # Test Grad-CAM++
    gradcam_pp = GradCAMPlusPlus(model, target_layer='layer4')
    cam_pp, _, _ = gradcam_pp.generate_cam(input_image)
    
    print(f"\nGrad-CAM++ shape: {cam_pp.shape}")
    print(f"CAM++ min: {cam_pp.min():.4f}, max: {cam_pp.max():.4f}")
    
    return gradcam, gradcam_pp


if __name__ == "__main__":
    test_gradcam()
