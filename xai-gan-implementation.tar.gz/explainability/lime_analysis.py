"""
LIME (Local Interpretable Model-agnostic Explanations) Analysis
For instance-level interpretability of vein authentication decisions
"""
import torch
import numpy as np
from lime import lime_image
from skimage.segmentation import mark_boundaries, slic
import matplotlib.pyplot as plt


class VeinLIMEAnalyzer:
    """
    LIME analyzer for dorsal hand vein authentication
    Provides local explanations by perturbing image regions
    """
    def __init__(self, model, device='cuda'):
        """
        Args:
            model: Trained authentication model
            device: Device to run computations
        """
        self.model = model
        self.device = device
        self.model.to(device)
        self.model.eval()
        
        # Create LIME explainer
        self.explainer = lime_image.LimeImageExplainer()
    
    def batch_predict(self, images):
        """
        Batch prediction function for LIME
        
        Args:
            images: numpy array of images (N, H, W, C) or (N, H, W)
            
        Returns:
            predictions: Probability distributions (N, num_classes)
        """
        # Handle grayscale images
        if images.ndim == 3:
            images = np.expand_dims(images, axis=-1)
        
        # Convert to torch tensor
        # LIME gives (N, H, W, C), we need (N, C, H, W)
        images_tensor = torch.FloatTensor(images).permute(0, 3, 1, 2)
        images_tensor = images_tensor.to(self.device)
        
        # Get predictions
        with torch.no_grad():
            outputs = self.model(images_tensor)
            probabilities = torch.softmax(outputs, dim=1)
        
        return probabilities.cpu().numpy()
    
    def explain_instance(self, input_image, num_samples=1000, 
                        num_features=10, hide_color=0):
        """
        Generate LIME explanation for a single instance
        
        Args:
            input_image: Input image (1, C, H, W) or (C, H, W) or (H, W, C)
            num_samples: Number of perturbed samples
            num_features: Number of superpixels to show in explanation
            hide_color: Color to use for hidden regions
            
        Returns:
            explanation: LIME explanation object
            prediction: Model prediction
        """
        # Convert to numpy and proper format
        if isinstance(input_image, torch.Tensor):
            image = input_image.cpu().numpy()
        else:
            image = input_image
        
        # Handle different input formats
        if image.ndim == 4:  # (1, C, H, W)
            image = image[0].transpose(1, 2, 0)  # (H, W, C)
        elif image.ndim == 3 and image.shape[0] <= 3:  # (C, H, W)
            image = image.transpose(1, 2, 0)  # (H, W, C)
        
        # Ensure grayscale is (H, W, 1)
        if image.ndim == 2:
            image = np.expand_dims(image, axis=-1)
        
        # Get prediction
        image_tensor = torch.FloatTensor(image).permute(2, 0, 1).unsqueeze(0)
        image_tensor = image_tensor.to(self.device)
        
        with torch.no_grad():
            output = self.model(image_tensor)
            pred_class = output.argmax(dim=1).item()
            probabilities = torch.softmax(output, dim=1).cpu().numpy()[0]
        
        # Generate LIME explanation
        explanation = self.explainer.explain_instance(
            image,
            self.batch_predict,
            top_labels=5,
            hide_color=hide_color,
            num_samples=num_samples,
            segmentation_fn=lambda x: slic(x, n_segments=100, compactness=10)
        )
        
        return explanation, pred_class, probabilities
    
    def visualize_explanation(self, input_image, explanation, 
                             pred_class, num_features=10, 
                             positive_only=True, save_path=None):
        """
        Visualize LIME explanation
        
        Args:
            input_image: Original input image
            explanation: LIME explanation object
            pred_class: Predicted class
            num_features: Number of features to show
            positive_only: Show only positive contributions
            save_path: Path to save visualization
        """
        # Convert input image to proper format
        if isinstance(input_image, torch.Tensor):
            image = input_image.cpu().numpy()
        else:
            image = input_image
        
        if image.ndim == 4:
            image = image[0].transpose(1, 2, 0)
        elif image.ndim == 3 and image.shape[0] <= 3:
            image = image.transpose(1, 2, 0)
        
        if image.ndim == 2:
            image = np.expand_dims(image, axis=-1)
        
        # Normalize image for display
        image_display = (image - image.min()) / (image.max() - image.min() + 1e-8)
        
        # Get explanation for predicted class
        temp, mask = explanation.get_image_and_mask(
            pred_class,
            positive_only=positive_only,
            num_features=num_features,
            hide_rest=False
        )
        
        # Create visualization
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        # Original image
        if image.shape[-1] == 1:
            axes[0].imshow(image_display[:, :, 0], cmap='gray')
        else:
            axes[0].imshow(image_display)
        axes[0].set_title(f'Original Image\nPredicted Class: {pred_class}')
        axes[0].axis('off')
        
        # LIME explanation with boundaries
        if image.shape[-1] == 1:
            marked = mark_boundaries(image_display[:, :, 0], mask)
        else:
            marked = mark_boundaries(image_display, mask)
        
        axes[1].imshow(marked)
        axes[1].set_title(f'LIME Explanation\n(Top {num_features} features)')
        axes[1].axis('off')
        
        # Mask only
        axes[2].imshow(mask, cmap='RdYlGn')
        axes[2].set_title('Feature Importance Mask')
        axes[2].axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def analyze_feature_importance(self, explanation, pred_class, threshold=0.01):
        """
        Analyze which superpixels are most important
        
        Args:
            explanation: LIME explanation object
            pred_class: Predicted class
            threshold: Minimum importance threshold
            
        Returns:
            important_features: List of important features with weights
        """
        # Get feature weights for predicted class
        local_exp = explanation.local_exp[pred_class]
        
        # Sort by absolute importance
        sorted_features = sorted(local_exp, key=lambda x: abs(x[1]), reverse=True)
        
        # Filter by threshold
        important_features = [
            {
                'superpixel_id': feat[0],
                'weight': feat[1],
                'positive': feat[1] > 0
            }
            for feat in sorted_features
            if abs(feat[1]) >= threshold
        ]
        
        return important_features
    
    def batch_explain(self, dataloader, num_samples_per_image=1000, 
                     max_images=10):
        """
        Generate LIME explanations for multiple images
        
        Args:
            dataloader: DataLoader with images
            num_samples_per_image: LIME samples per image
            max_images: Maximum number of images to explain
            
        Returns:
            explanations: List of explanation objects
            predictions: List of predictions
            labels: List of true labels
        """
        explanations = []
        predictions = []
        labels = []
        
        for i, (images, lbls) in enumerate(dataloader):
            if i >= max_images:
                break
            
            for img, lbl in zip(images, lbls):
                exp, pred, _ = self.explain_instance(
                    img,
                    num_samples=num_samples_per_image
                )
                
                explanations.append(exp)
                predictions.append(pred)
                labels.append(lbl.item())
        
        return explanations, predictions, labels
    
    def compare_explanations(self, input_image, top_k=3):
        """
        Compare explanations for top-k predicted classes
        
        Args:
            input_image: Input image
            top_k: Number of top classes to compare
            
        Returns:
            fig: Comparison visualization
            class_explanations: Dictionary of explanations per class
        """
        # Get prediction
        if isinstance(input_image, torch.Tensor):
            image_tensor = input_image.to(self.device)
        else:
            image = np.array(input_image)
            if image.ndim == 3:
                image_tensor = torch.FloatTensor(image).permute(2, 0, 1).unsqueeze(0)
            else:
                image_tensor = torch.FloatTensor(image).unsqueeze(0).unsqueeze(0)
            image_tensor = image_tensor.to(self.device)
        
        with torch.no_grad():
            output = self.model(image_tensor)
            probabilities = torch.softmax(output, dim=1).cpu().numpy()[0]
            top_classes = probabilities.argsort()[-top_k:][::-1]
        
        # Generate explanation
        explanation, _, _ = self.explain_instance(input_image)
        
        # Prepare image for visualization
        if isinstance(input_image, torch.Tensor):
            image = input_image.cpu().numpy()
        else:
            image = input_image
        
        if image.ndim == 4:
            image = image[0].transpose(1, 2, 0)
        elif image.ndim == 3 and image.shape[0] <= 3:
            image = image.transpose(1, 2, 0)
        
        image_display = (image - image.min()) / (image.max() - image.min() + 1e-8)
        
        # Create comparison visualization
        fig, axes = plt.subplots(1, top_k + 1, figsize=(5 * (top_k + 1), 5))
        
        # Original image
        if image.shape[-1] == 1:
            axes[0].imshow(image_display[:, :, 0], cmap='gray')
        else:
            axes[0].imshow(image_display)
        axes[0].set_title('Original')
        axes[0].axis('off')
        
        # Explanations for each class
        class_explanations = {}
        for i, class_idx in enumerate(top_classes):
            temp, mask = explanation.get_image_and_mask(
                class_idx,
                positive_only=False,
                num_features=10,
                hide_rest=False
            )
            
            if image.shape[-1] == 1:
                marked = mark_boundaries(image_display[:, :, 0], mask)
            else:
                marked = mark_boundaries(image_display, mask)
            
            axes[i + 1].imshow(marked)
            axes[i + 1].set_title(f'Class {class_idx}\nProb: {probabilities[class_idx]:.3f}')
            axes[i + 1].axis('off')
            
            class_explanations[class_idx] = {
                'mask': mask,
                'probability': probabilities[class_idx]
            }
        
        plt.tight_layout()
        
        return fig, class_explanations


def test_lime_analyzer():
    """Test LIME analyzer"""
    from models.classifier import VeinAuthenticationClassifier
    
    # Create dummy model
    model = VeinAuthenticationClassifier(num_classes=10)
    
    # Create analyzer
    analyzer = VeinLIMEAnalyzer(model, device='cpu')
    
    # Test single instance
    test_image = torch.randn(1, 1, 224, 224)
    explanation, pred, probs = analyzer.explain_instance(
        test_image,
        num_samples=100  # Reduced for testing
    )
    
    print(f"Predicted class: {pred}")
    print(f"Top 3 probabilities: {sorted(probs, reverse=True)[:3]}")
    
    # Analyze important features
    important = analyzer.analyze_feature_importance(explanation, pred)
    print(f"\nNumber of important features: {len(important)}")
    if important:
        print(f"Top feature weight: {important[0]['weight']:.4f}")
    
    return analyzer


if __name__ == "__main__":
    test_lime_analyzer()
