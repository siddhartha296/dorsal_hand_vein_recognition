"""
GAN Training Script with WGAN-GP
Trains generator and discriminator for synthetic vein pattern generation
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image, make_grid
import numpy as np
import os
from tqdm import tqdm
import matplotlib.pyplot as plt

from models.generator import Generator
from models.discriminator import Discriminator, gradient_penalty
from utils.config import Config


class GANTrainer:
    """
    Trainer for Wasserstein GAN with Gradient Penalty (WGAN-GP)
    """
    def __init__(self, generator, discriminator, config):
        """
        Args:
            generator: Generator network
            discriminator: Discriminator network
            config: Configuration object
        """
        self.generator = generator.to(config.DEVICE)
        self.discriminator = discriminator.to(config.DEVICE)
        self.config = config
        
        # Optimizers
        self.optimizer_G = optim.Adam(
            self.generator.parameters(),
            lr=config.LEARNING_RATE_G,
            betas=(config.BETA1, config.BETA2)
        )
        
        self.optimizer_D = optim.Adam(
            self.discriminator.parameters(),
            lr=config.LEARNING_RATE_D,
            betas=(config.BETA1, config.BETA2)
        )
        
        # Loss tracking
        self.losses_G = []
        self.losses_D = []
        self.wasserstein_distances = []
        
        # Fixed noise for visualization
        self.fixed_noise = torch.randn(
            64, config.LATENT_DIM, device=config.DEVICE
        )
        
        # Create output directories
        os.makedirs(config.OUTPUT_PATH, exist_ok=True)
        os.makedirs(config.MODEL_PATH, exist_ok=True)
        os.makedirs(f"{config.OUTPUT_PATH}/samples", exist_ok=True)
        
    def train_discriminator(self, real_images):
        """
        Train discriminator for one iteration
        
        Args:
            real_images: Batch of real vein images
            
        Returns:
            loss_D: Discriminator loss
            wasserstein_distance: Wasserstein distance estimate
        """
        batch_size = real_images.size(0)
        real_images = real_images.to(self.config.DEVICE)
        
        # Zero gradients
        self.optimizer_D.zero_grad()
        
        # Real images
        real_validity = self.discriminator(real_images)
        
        # Fake images
        noise = torch.randn(batch_size, self.config.LATENT_DIM, device=self.config.DEVICE)
        fake_images = self.generator(noise).detach()
        fake_validity = self.discriminator(fake_images)
        
        # Gradient penalty
        gp = gradient_penalty(
            self.discriminator,
            real_images,
            fake_images,
            self.config.DEVICE
        )
        
        # Wasserstein distance
        wasserstein_distance = real_validity.mean() - fake_validity.mean()
        
        # Total discriminator loss
        loss_D = -wasserstein_distance + self.config.LAMBDA_GP * gp
        
        # Backward and optimize
        loss_D.backward()
        self.optimizer_D.step()
        
        return loss_D.item(), wasserstein_distance.item()
    
    def train_generator(self):
        """
        Train generator for one iteration
        
        Returns:
            loss_G: Generator loss
        """
        # Zero gradients
        self.optimizer_G.zero_grad()
        
        # Generate fake images
        noise = torch.randn(
            self.config.BATCH_SIZE,
            self.config.LATENT_DIM,
            device=self.config.DEVICE
        )
        fake_images = self.generator(noise)
        
        # Discriminator evaluation
        fake_validity = self.discriminator(fake_images)
        
        # Generator loss (wants discriminator to think images are real)
        loss_G = -fake_validity.mean()
        
        # Backward and optimize
        loss_G.backward()
        self.optimizer_G.step()
        
        return loss_G.item()
    
    def train_epoch(self, dataloader, epoch):
        """
        Train for one epoch
        
        Args:
            dataloader: DataLoader with real vein images
            epoch: Current epoch number
            
        Returns:
            avg_loss_G: Average generator loss
            avg_loss_D: Average discriminator loss
        """
        self.generator.train()
        self.discriminator.train()
        
        epoch_loss_G = []
        epoch_loss_D = []
        epoch_wd = []
        
        pbar = tqdm(dataloader, desc=f"Epoch {epoch+1}/{self.config.EPOCHS_GAN}")
        
        for i, (real_images, _) in enumerate(pbar):
            # Train Discriminator
            loss_D, wd = self.train_discriminator(real_images)
            epoch_loss_D.append(loss_D)
            epoch_wd.append(wd)
            
            # Train Generator (every n_critic iterations)
            if i % self.config.N_CRITIC == 0:
                loss_G = self.train_generator()
                epoch_loss_G.append(loss_G)
            
            # Update progress bar
            if len(epoch_loss_G) > 0:
                pbar.set_postfix({
                    'D_loss': f'{loss_D:.4f}',
                    'G_loss': f'{epoch_loss_G[-1]:.4f}',
                    'W_dist': f'{wd:.4f}'
                })
        
        avg_loss_G = np.mean(epoch_loss_G) if epoch_loss_G else 0
        avg_loss_D = np.mean(epoch_loss_D)
        avg_wd = np.mean(epoch_wd)
        
        return avg_loss_G, avg_loss_D, avg_wd
    
    def generate_samples(self, num_samples=64, save_path=None):
        """
        Generate sample images from generator
        
        Args:
            num_samples: Number of samples to generate
            save_path: Path to save generated samples
            
        Returns:
            samples: Generated images
        """
        self.generator.eval()
        
        with torch.no_grad():
            noise = torch.randn(num_samples, self.config.LATENT_DIM, device=self.config.DEVICE)
            samples = self.generator(noise)
        
        if save_path:
            # Normalize to [0, 1] for saving
            samples_normalized = (samples + 1) / 2  # From [-1, 1] to [0, 1]
            save_image(samples_normalized, save_path, nrow=8, normalize=False)
        
        return samples
    
    def visualize_progress(self, epoch):
        """
        Visualize training progress with fixed noise
        
        Args:
            epoch: Current epoch number
        """
        self.generator.eval()
        
        with torch.no_grad():
            fake_images = self.generator(self.fixed_noise)
        
        # Normalize to [0, 1]
        fake_images = (fake_images + 1) / 2
        
        # Save grid of images
        save_path = f"{self.config.OUTPUT_PATH}/samples/epoch_{epoch+1:04d}.png"
        save_image(fake_images, save_path, nrow=8)
        
        # Also create a matplotlib figure
        grid = make_grid(fake_images, nrow=8).cpu()
        
        fig, ax = plt.subplots(figsize=(12, 12))
        ax.imshow(grid.permute(1, 2, 0), cmap='gray')
        ax.axis('off')
        ax.set_title(f'Generated Samples - Epoch {epoch+1}')
        
        fig_path = f"{self.config.OUTPUT_PATH}/samples/epoch_{epoch+1:04d}_plot.png"
        plt.savefig(fig_path, dpi=150, bbox_inches='tight')
        plt.close()
    
    def plot_losses(self, save_path=None):
        """
        Plot training losses
        
        Args:
            save_path: Path to save plot
        """
        fig, axes = plt.subplots(1, 2, figsize=(15, 5))
        
        # Generator and Discriminator losses
        axes[0].plot(self.losses_G, label='Generator', alpha=0.7)
        axes[0].plot(self.losses_D, label='Discriminator', alpha=0.7)
        axes[0].set_xlabel('Epoch')
        axes[0].set_ylabel('Loss')
        axes[0].set_title('GAN Training Losses')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Wasserstein distance
        axes[1].plot(self.wasserstein_distances, color='green', alpha=0.7)
        axes[1].set_xlabel('Epoch')
        axes[1].set_ylabel('Wasserstein Distance')
        axes[1].set_title('Wasserstein Distance Over Training')
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.savefig(f"{self.config.OUTPUT_PATH}/training_curves.png", dpi=150)
        
        plt.close()
    
    def save_checkpoint(self, epoch, save_path=None):
        """
        Save model checkpoint
        
        Args:
            epoch: Current epoch
            save_path: Path to save checkpoint
        """
        if save_path is None:
            save_path = f"{self.config.MODEL_PATH}/gan_checkpoint_epoch_{epoch+1}.pth"
        
        checkpoint = {
            'epoch': epoch,
            'generator_state_dict': self.generator.state_dict(),
            'discriminator_state_dict': self.discriminator.state_dict(),
            'optimizer_G_state_dict': self.optimizer_G.state_dict(),
            'optimizer_D_state_dict': self.optimizer_D.state_dict(),
            'losses_G': self.losses_G,
            'losses_D': self.losses_D,
            'wasserstein_distances': self.wasserstein_distances,
        }
        
        torch.save(checkpoint, save_path)
        print(f"Checkpoint saved to {save_path}")
    
    def load_checkpoint(self, checkpoint_path):
        """
        Load model checkpoint
        
        Args:
            checkpoint_path: Path to checkpoint file
        """
        checkpoint = torch.load(checkpoint_path, map_location=self.config.DEVICE)
        
        self.generator.load_state_dict(checkpoint['generator_state_dict'])
        self.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
        self.optimizer_G.load_state_dict(checkpoint['optimizer_G_state_dict'])
        self.optimizer_D.load_state_dict(checkpoint['optimizer_D_state_dict'])
        
        self.losses_G = checkpoint['losses_G']
        self.losses_D = checkpoint['losses_D']
        self.wasserstein_distances = checkpoint['wasserstein_distances']
        
        epoch = checkpoint['epoch']
        print(f"Checkpoint loaded from epoch {epoch+1}")
        
        return epoch
    
    def train(self, dataloader, num_epochs=None, resume_from=None):
        """
        Full training loop
        
        Args:
            dataloader: DataLoader with training data
            num_epochs: Number of epochs (if None, use config)
            resume_from: Path to checkpoint to resume from
            
        Returns:
            Training history
        """
        if num_epochs is None:
            num_epochs = self.config.EPOCHS_GAN
        
        start_epoch = 0
        if resume_from:
            start_epoch = self.load_checkpoint(resume_from) + 1
        
        print(f"Starting GAN training for {num_epochs} epochs...")
        print(f"Device: {self.config.DEVICE}")
        print(f"Batch size: {self.config.BATCH_SIZE}")
        print(f"Latent dim: {self.config.LATENT_DIM}")
        
        for epoch in range(start_epoch, num_epochs):
            # Train for one epoch
            avg_loss_G, avg_loss_D, avg_wd = self.train_epoch(dataloader, epoch)
            
            # Track losses
            self.losses_G.append(avg_loss_G)
            self.losses_D.append(avg_loss_D)
            self.wasserstein_distances.append(avg_wd)
            
            # Print epoch summary
            print(f"\nEpoch [{epoch+1}/{num_epochs}]")
            print(f"  Generator Loss: {avg_loss_G:.4f}")
            print(f"  Discriminator Loss: {avg_loss_D:.4f}")
            print(f"  Wasserstein Distance: {avg_wd:.4f}")
            
            # Visualize progress
            if (epoch + 1) % self.config.VISUALIZE_INTERVAL == 0:
                self.visualize_progress(epoch)
                self.plot_losses()
            
            # Save checkpoint
            if (epoch + 1) % self.config.SAVE_INTERVAL == 0:
                self.save_checkpoint(epoch)
        
        # Save final models
        self.save_checkpoint(num_epochs - 1, 
                           f"{self.config.MODEL_PATH}/gan_final.pth")
        self.plot_losses()
        
        print("\nTraining completed!")
        
        return {
            'losses_G': self.losses_G,
            'losses_D': self.losses_D,
            'wasserstein_distances': self.wasserstein_distances
        }


def main():
    """Main training function"""
    # Configuration
    config = Config()
    
    # Set random seed
    torch.manual_seed(config.SEED)
    np.random.seed(config.SEED)
    
    # Initialize models
    generator = Generator(
        latent_dim=config.LATENT_DIM,
        img_channels=config.IMG_CHANNELS,
        features=config.GEN_FEATURES
    )
    
    discriminator = Discriminator(
        img_channels=config.IMG_CHANNELS,
        features=config.DISC_FEATURES
    )
    
    print(f"Generator Parameters: {sum(p.numel() for p in generator.parameters()):,}")
    print(f"Discriminator Parameters: {sum(p.numel() for p in discriminator.parameters()):,}")
    
    # Create trainer
    trainer = GANTrainer(generator, discriminator, config)
    
    # TODO: Load actual dataloader
    # For now, create dummy dataloader
    from torch.utils.data import TensorDataset
    dummy_data = torch.randn(1000, 1, 224, 224)
    dummy_labels = torch.zeros(1000, dtype=torch.long)
    dataset = TensorDataset(dummy_data, dummy_labels)
    dataloader = DataLoader(dataset, batch_size=config.BATCH_SIZE, shuffle=True)
    
    # Train
    history = trainer.train(dataloader)
    
    # Generate final samples
    trainer.generate_samples(
        num_samples=64,
        save_path=f"{config.OUTPUT_PATH}/final_samples.png"
    )


if __name__ == "__main__":
    main()
