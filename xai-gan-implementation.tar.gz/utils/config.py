"""
Configuration file for XAI-GAN Dorsal Hand Vein Authentication
"""
import torch

class Config:
    # Device configuration
    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Dataset paths
    JILIN_PATH = './data/jilin/'
    HANDS_11K_PATH = './data/11k_hands/'
    OUTPUT_PATH = './outputs/'
    MODEL_PATH = './saved_models/'
    
    # Image specifications
    IMG_HEIGHT = 224
    IMG_WIDTH = 224
    IMG_CHANNELS = 1  # Grayscale NIR images
    
    # GAN Architecture
    LATENT_DIM = 100
    GEN_FEATURES = 64
    DISC_FEATURES = 64
    ATTENTION_HEADS = 8
    
    # Training hyperparameters
    BATCH_SIZE = 32
    EPOCHS_GAN = 200
    EPOCHS_CLASSIFIER = 100
    LEARNING_RATE_G = 0.0002
    LEARNING_RATE_D = 0.0002
    LEARNING_RATE_C = 0.001
    BETA1 = 0.5
    BETA2 = 0.999
    
    # GAN training
    N_CRITIC = 5  # Train discriminator n times per generator
    LAMBDA_GP = 10  # Gradient penalty coefficient
    
    # Data augmentation
    ROTATION_RANGE = 15
    TRANSLATION_RANGE = 0.1
    ZOOM_RANGE = 0.1
    
    # Explainability
    GRADCAM_LAYER = 'layer4'  # ResNet layer for Grad-CAM
    SHAP_SAMPLES = 100
    LIME_SAMPLES = 1000
    
    # Fairness
    FAIRNESS_THRESHOLD = 0.02  # 2% demographic parity threshold
    AGE_GROUPS = ['18-30', '31-50', '51-75']
    GENDERS = ['Male', 'Female']
    
    # Evaluation
    TRAIN_SPLIT = 0.7
    VAL_SPLIT = 0.15
    TEST_SPLIT = 0.15
    
    # Target metrics
    TARGET_ACCURACY_JILIN = 0.9836
    TARGET_ACCURACY_11K = 0.9643
    
    # Logging
    LOG_INTERVAL = 10
    SAVE_INTERVAL = 20
    VISUALIZE_INTERVAL = 50
    
    # Random seed for reproducibility
    SEED = 42
