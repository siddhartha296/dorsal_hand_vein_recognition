"""
Test script to verify all components are working correctly
"""
import sys
import torch
import numpy as np

def test_imports():
    """Test all required imports"""
    print("Testing imports...")
    
    try:
        import torch
        import torchvision
        import numpy
        import cv2
        import sklearn
        import shap
        import lime
        import matplotlib
        import seaborn
        print("✓ All imports successful")
        return True
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False


def test_models():
    """Test model architectures"""
    print("\nTesting model architectures...")
    
    try:
        from models.generator import Generator
        from models.discriminator import Discriminator
        from models.classifier import VeinAuthenticationClassifier
        
        # Test Generator
        gen = Generator(latent_dim=100, img_channels=1)
        z = torch.randn(2, 100)
        output = gen(z)
        assert output.shape == (2, 1, 224, 224), f"Generator output shape mismatch: {output.shape}"
        print("✓ Generator working correctly")
        
        # Test Discriminator
        disc = Discriminator(img_channels=1)
        x = torch.randn(2, 1, 224, 224)
        output = disc(x)
        assert output.shape == (2, 1), f"Discriminator output shape mismatch: {output.shape}"
        print("✓ Discriminator working correctly")
        
        # Test Classifier
        clf = VeinAuthenticationClassifier(num_classes=10)
        output = clf(x)
        assert output.shape == (2, 10), f"Classifier output shape mismatch: {output.shape}"
        print("✓ Classifier working correctly")
        
        return True
    except Exception as e:
        print(f"✗ Model test failed: {e}")
        return False


def test_explainability():
    """Test explainability modules"""
    print("\nTesting explainability modules...")
    
    try:
        from models.classifier import VeinAuthenticationClassifier
        from explainability.gradcam import GradCAM
        from explainability.shap_analysis import VeinSHAPAnalyzer
        from explainability.lime_analysis import VeinLIMEAnalyzer
        
        # Create model
        model = VeinAuthenticationClassifier(num_classes=10)
        model.eval()
        
        # Test Grad-CAM
        gradcam = GradCAM(model, target_layer='layer4')
        test_img = torch.randn(1, 1, 224, 224)
        cam, _, _ = gradcam.generate_cam(test_img)
        assert cam.shape == (7, 7) or cam.shape == (14, 14), f"CAM shape unexpected: {cam.shape}"
        print("✓ Grad-CAM working correctly")
        
        # Test SHAP (lightweight test)
        background = torch.randn(5, 1, 224, 224)
        shap_analyzer = VeinSHAPAnalyzer(model, background, device='cpu')
        shap_analyzer.create_explainer(method='gradient')
        shap_vals, _ = shap_analyzer.explain_instance(test_img)
        print("✓ SHAP working correctly")
        
        # Test LIME (minimal samples)
        lime_analyzer = VeinLIMEAnalyzer(model, device='cpu')
        explanation, _, _ = lime_analyzer.explain_instance(test_img, num_samples=50)
        print("✓ LIME working correctly")
        
        return True
    except Exception as e:
        print(f"✗ Explainability test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_fairness():
    """Test fairness analysis"""
    print("\nTesting fairness analysis...")
    
    try:
        from models.classifier import VeinAuthenticationClassifier
        from fairness.bias_detection import FairnessAnalyzer
        from torch.utils.data import TensorDataset, DataLoader
        
        # Create model
        model = VeinAuthenticationClassifier(num_classes=10)
        
        # Create analyzer
        analyzer = FairnessAnalyzer(model, device='cpu')
        
        # Create dummy data
        data = torch.randn(50, 1, 224, 224)
        labels = torch.randint(0, 10, (50,))
        dataset = TensorDataset(data, labels)
        loader = DataLoader(dataset, batch_size=8)
        
        # Test evaluation
        metrics = analyzer.evaluate_group(loader, "test_group")
        assert 'accuracy' in metrics
        assert 'far' in metrics
        assert 'frr' in metrics
        print("✓ Fairness analysis working correctly")
        
        return True
    except Exception as e:
        print(f"✗ Fairness test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_config():
    """Test configuration"""
    print("\nTesting configuration...")
    
    try:
        from utils.config import Config
        
        config = Config()
        assert config.LATENT_DIM == 100
        assert config.IMG_HEIGHT == 224
        assert config.IMG_WIDTH == 224
        print("✓ Configuration loaded correctly")
        
        return True
    except Exception as e:
        print(f"✗ Config test failed: {e}")
        return False


def main():
    """Run all tests"""
    print("="*60)
    print("XAI-GAN Component Tests")
    print("="*60)
    
    results = []
    
    results.append(("Imports", test_imports()))
    results.append(("Configuration", test_config()))
    results.append(("Models", test_models()))
    results.append(("Explainability", test_explainability()))
    results.append(("Fairness", test_fairness()))
    
    print("\n" + "="*60)
    print("Test Summary")
    print("="*60)
    
    for name, passed in results:
        status = "✓ PASSED" if passed else "✗ FAILED"
        print(f"{name:20s}: {status}")
    
    all_passed = all(result[1] for result in results)
    
    print("\n" + "="*60)
    if all_passed:
        print("All tests passed! ✓")
        print("\nYou're ready to start training!")
        print("Next steps:")
        print("1. Download datasets (see IMPLEMENTATION_GUIDE.md)")
        print("2. Run: python training/train_gan.py")
        print("3. Run: python training/train_classifier.py")
    else:
        print("Some tests failed. Please check the errors above.")
    print("="*60)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
