"""
Authentication Classifier for Dorsal Hand Vein Recognition
Uses ResNet backbone for feature extraction
"""
import torch
import torch.nn as nn
import torchvision.models as models


class VeinAuthenticationClassifier(nn.Module):
    """
    Classification model for vein-based biometric authentication
    
    Architecture:
    - Backbone: ResNet-50 (pretrained on ImageNet, fine-tuned)
    - Input: Vein image (1 x 224 x 224)
    - Output: Identity prediction + embedding for verification
    """
    def __init__(self, num_classes, embedding_dim=512, pretrained=True):
        super(VeinAuthenticationClassifier, self).__init__()
        
        self.num_classes = num_classes
        self.embedding_dim = embedding_dim
        
        # Load pretrained ResNet-50
        resnet = models.resnet50(pretrained=pretrained)
        
        # Modify first conv layer for grayscale input
        self.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        if pretrained:
            # Initialize from pretrained RGB weights (average across channels)
            self.conv1.weight.data = resnet.conv1.weight.data.mean(dim=1, keepdim=True)
        
        # Use ResNet layers
        self.bn1 = resnet.bn1
        self.relu = resnet.relu
        self.maxpool = resnet.maxpool
        
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        
        self.avgpool = resnet.avgpool
        
        # Feature dimension from ResNet-50
        resnet_feature_dim = 2048
        
        # Embedding layer for verification
        self.embedding = nn.Sequential(
            nn.Linear(resnet_feature_dim, embedding_dim),
            nn.BatchNorm1d(embedding_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5)
        )
        
        # Classification head for identification
        self.classifier = nn.Linear(embedding_dim, num_classes)
        
    def forward(self, x, return_embedding=False):
        # ResNet feature extraction
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        
        # Get embedding
        embedding = self.embedding(x)
        
        # Classification
        logits = self.classifier(embedding)
        
        if return_embedding:
            return logits, embedding
        return logits
    
    def get_embedding(self, x):
        """Extract embedding for verification tasks"""
        with torch.no_grad():
            _, embedding = self.forward(x, return_embedding=True)
        return embedding


class ArcFaceClassifier(nn.Module):
    """
    Classifier with ArcFace loss for better feature discrimination
    ArcFace adds angular margin to improve inter-class separability
    """
    def __init__(self, num_classes, embedding_dim=512, s=30.0, m=0.50):
        super(ArcFaceClassifier, self).__init__()
        
        self.num_classes = num_classes
        self.embedding_dim = embedding_dim
        self.s = s  # Scale parameter
        self.m = m  # Angular margin
        
        # Feature extractor (same as base classifier)
        resnet = models.resnet50(pretrained=True)
        
        # Modify for grayscale
        self.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.conv1.weight.data = resnet.conv1.weight.data.mean(dim=1, keepdim=True)
        
        self.bn1 = resnet.bn1
        self.relu = resnet.relu
        self.maxpool = resnet.maxpool
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.avgpool = resnet.avgpool
        
        # Embedding
        self.embedding = nn.Sequential(
            nn.Linear(2048, embedding_dim),
            nn.BatchNorm1d(embedding_dim)
        )
        
        # ArcFace classifier weights
        self.weight = nn.Parameter(torch.FloatTensor(num_classes, embedding_dim))
        nn.init.xavier_uniform_(self.weight)
        
    def forward(self, x, labels=None):
        # Extract features
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        
        # Embedding
        embedding = self.embedding(x)
        
        # Normalize features and weights
        embedding = nn.functional.normalize(embedding, p=2, dim=1)
        weight = nn.functional.normalize(self.weight, p=2, dim=1)
        
        # Cosine similarity
        cosine = nn.functional.linear(embedding, weight)
        
        if labels is not None and self.training:
            # ArcFace: add angular margin
            import math
            theta = torch.acos(torch.clamp(cosine, -1.0 + 1e-7, 1.0 - 1e-7))
            
            # Add margin to target class
            target_logits = torch.cos(theta + self.m)
            one_hot = torch.zeros_like(cosine)
            one_hot.scatter_(1, labels.view(-1, 1), 1)
            
            output = (one_hot * target_logits) + ((1.0 - one_hot) * cosine)
            output *= self.s
        else:
            output = cosine * self.s
            
        return output, embedding


class TripletNetwork(nn.Module):
    """
    Siamese network for triplet loss training
    Used for verification tasks (1:1 matching)
    """
    def __init__(self, embedding_dim=512):
        super(TripletNetwork, self).__init__()
        
        # Shared feature extractor
        resnet = models.resnet50(pretrained=True)
        
        # Modify for grayscale
        self.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.conv1.weight.data = resnet.conv1.weight.data.mean(dim=1, keepdim=True)
        
        self.bn1 = resnet.bn1
        self.relu = resnet.relu
        self.maxpool = resnet.maxpool
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.avgpool = resnet.avgpool
        
        # Embedding layer
        self.embedding = nn.Sequential(
            nn.Linear(2048, embedding_dim),
            nn.BatchNorm1d(embedding_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embedding_dim, embedding_dim),
            nn.BatchNorm1d(embedding_dim)
        )
        
    def forward_once(self, x):
        """Forward pass for a single image"""
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        
        embedding = self.embedding(x)
        return nn.functional.normalize(embedding, p=2, dim=1)
    
    def forward(self, anchor, positive, negative):
        """Forward pass for triplet"""
        anchor_emb = self.forward_once(anchor)
        positive_emb = self.forward_once(positive)
        negative_emb = self.forward_once(negative)
        
        return anchor_emb, positive_emb, negative_emb


def test_classifier():
    """Test classifier architectures"""
    batch_size = 4
    num_classes = 100
    img_channels = 1
    
    # Test base classifier
    print("Testing VeinAuthenticationClassifier...")
    model = VeinAuthenticationClassifier(num_classes=num_classes)
    x = torch.randn(batch_size, img_channels, 224, 224)
    
    logits = model(x)
    print(f"Output Shape: {logits.shape}")
    print(f"Expected: ({batch_size}, {num_classes})")
    print(f"Total Parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Test with embedding
    logits, embedding = model(x, return_embedding=True)
    print(f"\nEmbedding Shape: {embedding.shape}")
    
    # Test ArcFace
    print("\n\nTesting ArcFaceClassifier...")
    arcface = ArcFaceClassifier(num_classes=num_classes)
    labels = torch.randint(0, num_classes, (batch_size,))
    output, embedding = arcface(x, labels)
    print(f"Output Shape: {output.shape}")
    print(f"Embedding Shape: {embedding.shape}")
    
    # Test Triplet Network
    print("\n\nTesting TripletNetwork...")
    triplet_net = TripletNetwork()
    anchor, positive, negative = x, x, x
    a_emb, p_emb, n_emb = triplet_net(anchor, positive, negative)
    print(f"Anchor Embedding Shape: {a_emb.shape}")
    
    return model, arcface, triplet_net


if __name__ == "__main__":
    test_classifier()
