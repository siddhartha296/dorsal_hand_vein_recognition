"""
Fairness Analysis for Vein Authentication
Detects and measures demographic biases across age and gender groups
"""
import torch
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, accuracy_score
from collections import defaultdict


class FairnessAnalyzer:
    """
    Analyzer for detecting demographic biases in vein authentication
    """
    def __init__(self, model, device='cuda'):
        """
        Args:
            model: Trained authentication model
            device: Device for computations
        """
        self.model = model
        self.device = device
        self.model.to(device)
        self.model.eval()
        
        self.results = defaultdict(dict)
    
    def evaluate_group(self, dataloader, group_name):
        """
        Evaluate model performance on a demographic group
        
        Args:
            dataloader: DataLoader for the group
            group_name: Name of the demographic group
            
        Returns:
            metrics: Dictionary of performance metrics
        """
        all_predictions = []
        all_labels = []
        all_probabilities = []
        
        with torch.no_grad():
            for images, labels in dataloader:
                images = images.to(self.device)
                
                outputs = self.model(images)
                probabilities = torch.softmax(outputs, dim=1)
                predictions = outputs.argmax(dim=1)
                
                all_predictions.extend(predictions.cpu().numpy())
                all_labels.extend(labels.numpy())
                all_probabilities.extend(probabilities.cpu().numpy())
        
        # Compute metrics
        accuracy = accuracy_score(all_labels, all_predictions)
        
        # Compute FAR and FRR
        far, frr = self._compute_far_frr(
            np.array(all_labels),
            np.array(all_predictions),
            np.array(all_probabilities)
        )
        
        metrics = {
            'group': group_name,
            'accuracy': accuracy,
            'far': far,
            'frr': frr,
            'num_samples': len(all_labels),
            'predictions': all_predictions,
            'labels': all_labels,
            'probabilities': all_probabilities
        }
        
        self.results[group_name] = metrics
        
        return metrics
    
    def _compute_far_frr(self, labels, predictions, probabilities, threshold=0.5):
        """
        Compute False Acceptance Rate (FAR) and False Rejection Rate (FRR)
        
        Args:
            labels: True labels
            predictions: Predicted labels
            probabilities: Prediction probabilities
            threshold: Decision threshold
            
        Returns:
            far: False Acceptance Rate
            frr: False Rejection Rate
        """
        # For genuine attempts (same person)
        genuine_mask = labels == predictions
        genuine_scores = np.max(probabilities, axis=1)[genuine_mask]
        
        # For impostor attempts (different person)
        impostor_mask = labels != predictions
        impostor_scores = np.max(probabilities, axis=1)[impostor_mask]
        
        # FAR: Proportion of impostors accepted
        if len(impostor_scores) > 0:
            far = np.sum(impostor_scores >= threshold) / len(impostor_scores)
        else:
            far = 0.0
        
        # FRR: Proportion of genuine users rejected
        if len(genuine_scores) > 0:
            frr = np.sum(genuine_scores < threshold) / len(genuine_scores)
        else:
            frr = 0.0
        
        return far, frr
    
    def compute_demographic_parity(self, groups):
        """
        Compute demographic parity across groups
        
        Demographic parity: P(Y=1|A=a) ≈ P(Y=1|A=b) for all a, b
        
        Args:
            groups: List of group names to compare
            
        Returns:
            parity_metrics: Dictionary with parity statistics
        """
        accuracies = []
        fars = []
        frrs = []
        
        for group in groups:
            if group in self.results:
                accuracies.append(self.results[group]['accuracy'])
                fars.append(self.results[group]['far'])
                frrs.append(self.results[group]['frr'])
        
        parity_metrics = {
            'accuracy_disparity': max(accuracies) - min(accuracies),
            'far_disparity': max(fars) - min(fars),
            'frr_disparity': max(frrs) - min(frrs),
            'mean_accuracy': np.mean(accuracies),
            'std_accuracy': np.std(accuracies),
            'groups': groups,
            'accuracies': accuracies,
            'fars': fars,
            'frrs': frrs
        }
        
        return parity_metrics
    
    def compute_equalized_odds(self, group_a, group_b):
        """
        Compute equalized odds between two groups
        
        Equalized odds: P(Y=1|A=a,Y*=y) = P(Y=1|A=b,Y*=y) for y ∈ {0,1}
        
        Args:
            group_a: First group name
            group_b: Second group name
            
        Returns:
            odds_metrics: Dictionary with equalized odds metrics
        """
        if group_a not in self.results or group_b not in self.results:
            raise ValueError(f"Groups {group_a} or {group_b} not evaluated")
        
        metrics_a = self.results[group_a]
        metrics_b = self.results[group_b]
        
        # True Positive Rate (TPR) difference
        tpr_diff = abs(metrics_a['accuracy'] - metrics_b['accuracy'])
        
        # False Positive Rate (FPR) difference
        fpr_diff = abs(metrics_a['far'] - metrics_b['far'])
        
        odds_metrics = {
            'tpr_difference': tpr_diff,
            'fpr_difference': fpr_diff,
            'max_difference': max(tpr_diff, fpr_diff),
            'group_a': group_a,
            'group_b': group_b
        }
        
        return odds_metrics
    
    def analyze_age_fairness(self, dataloaders_by_age):
        """
        Analyze fairness across age groups
        
        Args:
            dataloaders_by_age: Dictionary {age_group: dataloader}
            
        Returns:
            age_analysis: Fairness analysis results
        """
        print("Analyzing age fairness...")
        
        # Evaluate each age group
        for age_group, dataloader in dataloaders_by_age.items():
            print(f"  Evaluating {age_group}...")
            self.evaluate_group(dataloader, age_group)
        
        # Compute demographic parity
        age_groups = list(dataloaders_by_age.keys())
        parity = self.compute_demographic_parity(age_groups)
        
        age_analysis = {
            'parity': parity,
            'groups': age_groups,
            'individual_results': {g: self.results[g] for g in age_groups}
        }
        
        return age_analysis
    
    def analyze_gender_fairness(self, dataloaders_by_gender):
        """
        Analyze fairness across gender groups
        
        Args:
            dataloaders_by_gender: Dictionary {gender: dataloader}
            
        Returns:
            gender_analysis: Fairness analysis results
        """
        print("Analyzing gender fairness...")
        
        # Evaluate each gender group
        for gender, dataloader in dataloaders_by_gender.items():
            print(f"  Evaluating {gender}...")
            self.evaluate_group(dataloader, gender)
        
        # Compute metrics
        genders = list(dataloaders_by_gender.keys())
        parity = self.compute_demographic_parity(genders)
        
        # If two genders, compute equalized odds
        equalized_odds = None
        if len(genders) == 2:
            equalized_odds = self.compute_equalized_odds(genders[0], genders[1])
        
        gender_analysis = {
            'parity': parity,
            'equalized_odds': equalized_odds,
            'groups': genders,
            'individual_results': {g: self.results[g] for g in genders}
        }
        
        return gender_analysis
    
    def visualize_fairness(self, analysis_results, save_path=None):
        """
        Visualize fairness analysis results
        
        Args:
            analysis_results: Results from fairness analysis
            save_path: Path to save visualization
        """
        groups = analysis_results['groups']
        parity = analysis_results['parity']
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Accuracy comparison
        accuracies = parity['accuracies']
        axes[0, 0].bar(groups, accuracies, color='steelblue', alpha=0.7)
        axes[0, 0].axhline(y=parity['mean_accuracy'], color='red', 
                           linestyle='--', label='Mean')
        axes[0, 0].set_ylabel('Accuracy')
        axes[0, 0].set_title('Accuracy Across Groups')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3, axis='y')
        
        # FAR comparison
        fars = parity['fars']
        axes[0, 1].bar(groups, fars, color='coral', alpha=0.7)
        axes[0, 1].set_ylabel('False Acceptance Rate')
        axes[0, 1].set_title('FAR Across Groups')
        axes[0, 1].grid(True, alpha=0.3, axis='y')
        
        # FRR comparison
        frrs = parity['frrs']
        axes[1, 0].bar(groups, frrs, color='seagreen', alpha=0.7)
        axes[1, 0].set_ylabel('False Rejection Rate')
        axes[1, 0].set_title('FRR Across Groups')
        axes[1, 0].grid(True, alpha=0.3, axis='y')
        
        # Disparity summary
        disparities = {
            'Accuracy': parity['accuracy_disparity'],
            'FAR': parity['far_disparity'],
            'FRR': parity['frr_disparity']
        }
        
        axes[1, 1].bar(disparities.keys(), disparities.values(), 
                       color='mediumpurple', alpha=0.7)
        axes[1, 1].axhline(y=0.02, color='red', linestyle='--', 
                          label='2% Threshold')
        axes[1, 1].set_ylabel('Disparity')
        axes[1, 1].set_title('Demographic Disparity (Max - Min)')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
        return fig
    
    def generate_fairness_report(self, age_analysis=None, gender_analysis=None):
        """
        Generate comprehensive fairness report
        
        Args:
            age_analysis: Age fairness analysis results
            gender_analysis: Gender fairness analysis results
            
        Returns:
            report: Dictionary with fairness metrics
        """
        report = {
            'summary': {},
            'age_fairness': age_analysis,
            'gender_fairness': gender_analysis,
            'compliance': {}
        }
        
        # Check compliance with fairness thresholds
        threshold = 0.02  # 2% as per paper
        
        if age_analysis:
            age_compliant = age_analysis['parity']['accuracy_disparity'] <= threshold
            report['compliance']['age'] = {
                'compliant': age_compliant,
                'disparity': age_analysis['parity']['accuracy_disparity'],
                'threshold': threshold
            }
        
        if gender_analysis:
            gender_compliant = gender_analysis['parity']['accuracy_disparity'] <= threshold
            report['compliance']['gender'] = {
                'compliant': gender_compliant,
                'disparity': gender_analysis['parity']['accuracy_disparity'],
                'threshold': threshold
            }
        
        # Overall summary
        all_accuracies = []
        if age_analysis:
            all_accuracies.extend(age_analysis['parity']['accuracies'])
        if gender_analysis:
            all_accuracies.extend(gender_analysis['parity']['accuracies'])
        
        report['summary'] = {
            'overall_mean_accuracy': np.mean(all_accuracies) if all_accuracies else 0,
            'overall_std_accuracy': np.std(all_accuracies) if all_accuracies else 0,
            'num_groups_evaluated': len(self.results)
        }
        
        return report
    
    def print_report(self, report):
        """Print fairness report to console"""
        print("\n" + "="*60)
        print("FAIRNESS ANALYSIS REPORT")
        print("="*60)
        
        print("\n--- SUMMARY ---")
        print(f"Overall Mean Accuracy: {report['summary']['overall_mean_accuracy']:.4f}")
        print(f"Overall Std Accuracy: {report['summary']['overall_std_accuracy']:.4f}")
        print(f"Groups Evaluated: {report['summary']['num_groups_evaluated']}")
        
        if 'age' in report['compliance']:
            print("\n--- AGE FAIRNESS ---")
            age_comp = report['compliance']['age']
            print(f"Accuracy Disparity: {age_comp['disparity']:.4f}")
            print(f"Threshold: {age_comp['threshold']:.4f}")
            print(f"Compliant: {'✓ YES' if age_comp['compliant'] else '✗ NO'}")
        
        if 'gender' in report['compliance']:
            print("\n--- GENDER FAIRNESS ---")
            gender_comp = report['compliance']['gender']
            print(f"Accuracy Disparity: {gender_comp['disparity']:.4f}")
            print(f"Threshold: {gender_comp['threshold']:.4f}")
            print(f"Compliant: {'✓ YES' if gender_comp['compliant'] else '✗ NO'}")
        
        print("\n" + "="*60)


def test_fairness_analyzer():
    """Test fairness analyzer"""
    from models.classifier import VeinAuthenticationClassifier
    from torch.utils.data import TensorDataset, DataLoader
    
    # Create dummy model
    model = VeinAuthenticationClassifier(num_classes=10)
    
    # Create analyzer
    analyzer = FairnessAnalyzer(model, device='cpu')
    
    # Create dummy dataloaders for different groups
    def create_dummy_loader(num_samples=100):
        data = torch.randn(num_samples, 1, 224, 224)
        labels = torch.randint(0, 10, (num_samples,))
        dataset = TensorDataset(data, labels)
        return DataLoader(dataset, batch_size=16)
    
    # Test age fairness
    age_loaders = {
        '18-30': create_dummy_loader(100),
        '31-50': create_dummy_loader(120),
        '51-75': create_dummy_loader(80)
    }
    
    age_analysis = analyzer.analyze_age_fairness(age_loaders)
    
    # Test gender fairness
    gender_loaders = {
        'Male': create_dummy_loader(150),
        'Female': create_dummy_loader(150)
    }
    
    gender_analysis = analyzer.analyze_gender_fairness(gender_loaders)
    
    # Generate report
    report = analyzer.generate_fairness_report(age_analysis, gender_analysis)
    analyzer.print_report(report)
    
    # Visualize
    analyzer.visualize_fairness(age_analysis)
    
    return analyzer, report


if __name__ == "__main__":
    test_fairness_analyzer()
