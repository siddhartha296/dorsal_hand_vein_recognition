# XAI-Enhanced GAN for Dorsal Hand Vein Biometric Authentication

## Project Overview
Implementation of "XAI-Enhanced Generative Adversarial Networks for Explainable Dorsal Hand Vein Biometric Authentication"

## Key Features
- **GAN Architecture**: Deep learning-based generative model for vein pattern synthesis
- **Explainability**: Integration of Grad-CAM, SHAP, and LIME
- **Fairness Analysis**: Demographic bias detection and mitigation
- **Attention Mechanisms**: Enhanced generator for better synthetic patterns

## Project Structure
```
xai-gan-vein-auth/
├── data/
│   ├── jilin/              # Jilin University dataset
│   ├── 11k_hands/          # 11K Hands dataset
│   └── preprocessed/       # Processed data
├── models/
│   ├── gan.py              # GAN architecture
│   ├── generator.py        # Generator with attention
│   ├── discriminator.py    # Discriminator network
│   └── classifier.py       # Authentication classifier
├── explainability/
│   ├── gradcam.py          # Grad-CAM implementation
│   ├── shap_analysis.py    # SHAP explanations
│   └── lime_analysis.py    # LIME explanations
├── fairness/
│   ├── bias_detection.py   # Demographic bias analysis
│   └── fairness_metrics.py # Fairness evaluation
├── preprocessing/
│   ├── image_processing.py # NIR image preprocessing
│   └── augmentation.py     # Data augmentation
├── training/
│   ├── train_gan.py        # GAN training loop
│   └── train_classifier.py # Classifier training
├── evaluation/
│   ├── metrics.py          # Accuracy, EER, FAR, FRR
│   └── visualization.py    # Result visualization
├── utils/
│   ├── config.py           # Configuration
│   └── helpers.py          # Utility functions
└── notebooks/
    ├── 01_data_exploration.ipynb
    ├── 02_model_training.ipynb
    └── 03_explainability_analysis.ipynb
```

## Requirements
- Python 3.8+
- PyTorch 2.0+
- torchvision
- NumPy
- OpenCV
- scikit-learn
- SHAP
- LIME
- Matplotlib
- Seaborn

## Installation
```bash
pip install torch torchvision numpy opencv-python scikit-learn shap lime matplotlib seaborn pandas pillow tqdm
```

## Datasets
1. **Jilin University Dorsal Hand Vein Database**
   - ~150 training images per class
   - ~100 test images per class
   - NIR grayscale images

2. **11K Hands Dataset**
   - 11,076 total images (1600×1200 pixels)
   - 190 subjects, ages 18-75
   - 5,680 dorsal hand images
   - Rich demographic metadata

## Implementation Phases

### Phase 1: Data Preprocessing
- [x] Dataset loading and organization
- [ ] NIR image enhancement
- [ ] Vein pattern extraction
- [ ] Data augmentation pipeline

### Phase 2: GAN Development
- [ ] Generator with attention mechanisms
- [ ] Discriminator network
- [ ] GAN training loop
- [ ] Synthetic vein pattern generation

### Phase 3: Classification Model
- [ ] Authentication classifier
- [ ] Feature extraction
- [ ] Model training and validation

### Phase 4: Explainability Integration
- [ ] Grad-CAM visualization
- [ ] SHAP global analysis
- [ ] LIME local explanations
- [ ] Explanation dashboard

### Phase 5: Fairness Analysis
- [ ] Demographic bias detection
- [ ] Fairness metrics computation
- [ ] Bias mitigation strategies

### Phase 6: Evaluation
- [ ] Accuracy metrics (98%+ target)
- [ ] User study preparation
- [ ] Performance benchmarking

## Target Metrics
- **Accuracy**: 98.36% (Jilin), 96.43% (11K Hands)
- **Demographic Parity**: <2% disparity
- **Trust Score Improvement**: 34%
- **Debug Speed**: 3.2× faster

## Citation
If you use this implementation, please cite:
```
[Your paper details here]
```

## License
Academic Research Use Only
